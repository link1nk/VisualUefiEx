// Standard EDK2/UEFI headers must be wrapped in extern "C" 
// to prevent C++ name mangling, as UEFI firmware uses C linkage.
extern "C"
{
#include <Uefi.h>                                // Base UEFI types and constants
#include <Library/UefiLib.h>                     // Common library functions (like Print)
#include <Library/MemoryAllocationLib.h>         // Functions for RAM management
#include <Library/UefiBootServicesTableLib.h>    // Access to gBS (Boot Services)
#include <Library/UefiRuntimeServicesTableLib.h> // Access to gRT (Runtime Services)
}

// Global variable to define the revision of this driver/app
extern "C" CONST UINT32 _gUefiDriverRevision = 0x200;

// The base name used by the shell and libraries to identify this module
extern "C" CHAR8* gEfiCallerBaseName = "UefiMain";

/**
  Unload lookup function.
**/
extern "C" EFI_STATUS EFIAPI UefiUnload(IN EFI_HANDLE ImageHandle)
{
    return EFI_SUCCESS;
}

/**
  The entry point for the UEFI Application.
  @param ImageHandle    The firmware-allocated handle for the current executable.
  @param SystemTable    A pointer to the EFI System Table (contains pointers to all UEFI services).
**/
extern "C" EFI_STATUS EFIAPI UefiMain(IN EFI_HANDLE ImageHandle, IN EFI_SYSTEM_TABLE* SystemTable)
{
    Print(L"My UEFI Application X\n");

    return EFI_SUCCESS;
}